<?php
session_start();

//Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login_restaurante";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: . $conn->connect_error");
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['registro'])) {
        $nombre = $_POST['nombre'];
        $correo = $_POST['correo'];
        $usuario = $_POST['usuario'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $query = "INSERT INTO clientes (nombre, correo, usuario, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $nombre, $correo, $usuario, $password);
        if ($stmt->execute()) {
            echo "<script>alert('Registro exitoso!');</script>";
        } else {
            echo "<script>alert('Error en el registro :(');</script>";
        }
    }

    if (isset($_POST['login'])) {
        $correo = $_POST['correo'];
        $password = $_POST['password'];

        $query = "SELECT * FROM clientes WHERE correo = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            if (password_verify($password, $usuario['password'])) {
                $_SESSION['usuario'] = $usuario['usuario'];
                header("Location: suscripcion.php");
                exit();
            } else {
                echo "<script>alert('Contraseña incorrecta >:|');</script>";
            }
        } else{
            echo "<script>alert('Usuario no encontrado :O');</script>";
        }
    }
}
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/login.css">
    <title>Inicio de Sesión</title>
</head>
<body>
    <main>
        <div class="contenedor_todo">
            <div class="caja_trasera">
                <div class="caja_trasera-login">
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para entrar en la página</p>
                    <button id="btn_iniciar-sesion">Iniciar Sesión</button>
                </div>
                <div class="caja_trasera-register">
                    <h3>¿Aún no tienes una cuenta?</h3>
                    <p>Registrate para que puedas iniciar sesión</p>
                    <button id="btn_registrarse">Regístrarse</button>
                </div>
            </div>

            <div class="contenedor_login-register">
                <form action="" method="POST" class="formulario_login">
                    <h2>Iniciar Sesión</h2>
                    <input type="text" name="correo" placeholder="Correo Electronico" required>
                    <input type="password" name="password" placeholder="Contraseña" required>
                    <button type="submit" name="login">Entrar</button>
                </form>

                <form action="" method="POST" class="formulario_register">
                    <h2>Regístrarse</h2>
                    <input type="text" name="nombre" placeholder="Nombre completo" required>
                    <input type="text" name="correo" placeholder="Correo Electronico" required>
                    <input type="text" name="usuario" placeholder="Usuario" required>
                    <input type="password" name="password" placeholder="Contraseña" required>
                    <button type="submit" name="registro">Regístrarse</button>
                </form>
            </div>
        </div>
    </main>
        <script src="js/script.js"></script>
</body>
</html>