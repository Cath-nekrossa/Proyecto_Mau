<?php
$server = 'localhost';
$user = 'root';
$pass = '';
$db = 'restaurante';

$conexion = new mysqli($server, $user, $pass, $db);

// if($conexion->connect_errno){
//     die('No se conecto'.$conexion-> connect_errno);
// } else {
//  echo'Conectado';
// }
?>

<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $telefono = htmlspecialchars($_POST['telefono']);
    $correo = htmlspecialchars($_POST['correo']);
    $ocasion = htmlspecialchars($_POST['ocasion']);
    $solicitud = htmlspecialchars($_POST['solicitud']);
    $nombre_tarjeta = htmlspecialchars($_POST['nombre_tarjeta']);
    $numero_tarjeta = htmlspecialchars($_POST['numero_tarjeta']);
    $fecha_exp = htmlspecialchars($_POST['fecha_exp']);
    $cvc = htmlspecialchars($_POST['cvc']);
    $codigo_postal = htmlspecialchars($_POST['codigo_postal']);

    $insertarDatos = "INSERT INTO reservaciones VALUE ('', '$telefono', '$correo', '$ocasion', '$solicitud', '$nombre_tarjeta', '$numero_tarjeta', '$fecha_exp', '$cvc', '$codigo_postal')";

    $ejecutarInsertar = mysqli_query($conexion, $insertarDatos);


    echo "<style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                padding: 20px;
                color: #333;
            }
            .ticket {
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
            h2 {
                color: #e91e63;
            }
            h3 {
                margin-top: 20px;
                color: #2196F3;
            }
            p {
                margin: 10px 0;
            }
            strong {
                color: #555;
            }
          </style>";

    echo "<div class='ticket'>";
    echo "<h2>Resumen de la Reservación</h2>";
    echo "<p><strong>Número de teléfono:</strong> $telefono</p>";
    echo "<p><strong>Correo electrónico:</strong> $correo</p>";
    echo "<p><strong>Ocasión:</strong> $ocasion</p>";
    echo "<p><strong>Solicitud especial:</strong> $solicitud</p>";
    echo "<h3>Método de pago</h3>";
    echo "<p><strong>Nombre en la tarjeta:</strong> $nombre_tarjeta</p>";
    echo "<p><strong>Número de tarjeta:</strong> $numero_tarjeta</p>";
    echo "<p><strong>Fecha de expiración:</strong> $fecha_exp</p>";
    echo "<p><strong>CVC:</strong> $cvc</p>";
    echo "<p><strong>Código postal:</strong> $codigo_postal</p>";
    echo "</div>";
}
?>
