-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-04-2025 a las 02:28:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `login_restaurante`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `correo`, `usuario`, `password`) VALUES
(1, 'Mario', 'eduardo@gmail.com', 'Punketo', '$2y$10$pAouwU1olauVU8nFb4pk3uX.kXxgr9QJfMeLMdW4OOWWLadB78L1W'),
(2, 'Ashley Karim', 'bolon@gmail.com', 'Bolas', '$2y$10$p6XYV9VswyA8DiKGIe2SOuSQFnXmEftmR69yNYaCHsjcDmL17DLZm'),
(3, 'Catherine Nicole García', 'catherine@gmail.com', 'Nekrossa', '$2y$10$hC1A0AP.GpPh0yIeX69ncu7DiZTYeOI93lpSlGALsTaau8ut0rtuy'),
(4, 'nico', 'XD@gmail.com', 'xd', '$2y$10$yc/rMM65KrRWQcNgpid19uWtzc9kCWK.7VUEQ70GPfBFQj/HVJQLi'),
(5, 'Leslie Victoria ', 'hola37@gmail.com', 'Leslie', '$2y$10$6CZVmIQRTEl.OfFz41VzceugCkHSO8N8TfFjjrhny1yMUUB.GSja2');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
