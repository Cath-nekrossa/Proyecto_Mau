<?php
session_start();

// Si el usuario no ha iniciado sesión,, lo redirige a login.php
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

//Si se presiona el botón de cerrar sesión, se destruye la sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membresía El Dragón Galés</title>
    <link rel="stylesheet" href="Estilos/suscripcion.css">
</head>
<body>
    
<div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="index.html">
                        <span class="icon">
                            <ion-icon name="restaurant-outline"></ion-icon>
                        </span>
                        <span class="title">El Dragón Galés</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Mi Perfil</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="calendar-outline"></ion-icon>
                        </span>
                        <span class="title">Mis Reservas</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Beneficios</span>
                    </a>
                </li>

                <li>
                    <!-- <a href="https://www.wales.com/es/acerca-de-gales/bienvenido-gales/bienvenidos-gales" target="_blank"> -->
                        <span class="icon">
                            <ion-icon name="receipt-outline"></ion-icon>
                        </span>
                        <span class="title">Historia</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="gift-outline"></ion-icon>
                        </span>
                        <span class="title">Promociones</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="help-outline"></ion-icon>
                        </span>
                        <span class="title">Ayuda</span>
                    </a>
                </li>

                <li>
                    <a href="login.php?logout=true">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Cerrar Sesión</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" placeholder="Buscar platillos...">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <div class="user">
                    <img src="Imagenes/Perfil.jpg" alt="Perfil de Usuario">
                </div>
            </div>

            <!-- Tarjetas -->
            <div class="cardBox">
                <div class="card">
                    <div>
                        <div class="numbers">6</div>
                        <div class="cardName">Visitas al Restaurante</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="restaurant-outline"></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <div>
                        <div class="numbers">3</div>
                        <div class="cardName">Reservas Pendientes</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="calendar-outline"></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <div>
                        <div class="numbers">450</div>
                        <div class="cardName">Puntos Acumulados</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="star-outline"></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <div>
                        <div class="numbers">Plata</div>
                        <div class="cardName">Nivel de Membresía</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="trophy-outline"></ion-icon>
                    </div>
                </div>
            </div>

            <!-- Detalles de la lista -->
             <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Mis Últimas Visitas</h2>
                        <a href="#" class="btn">Ver Todas</a>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <td>Fecha</td>
                                <td>Platillos</td>
                                <td>Total</td>
                                <td>Puntos Ganados</td>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>04/04/2025</td>
                                <td>Cawl Gales (2), Postres (2)</td>
                                <td>$850</td>
                                <td><span class="status delivered">+85 pts</span></td>
                            </tr>

                            <tr>
                                <td>20/03/2025</td>
                                <td>Welsh Rarebit, Laverbread</td>
                                <td>$480</td>
                                <td><span class="status delivered">+48 pts</span></td>
                            </tr>

                            <tr>
                                <td>10/03/2025</td>
                                <td>Cena Especial St. David</td>
                                <td>$1200</td>
                                <td><span class="status delivered">+120 pts</span></td>
                            </tr>

                            <tr>
                                <td>01/03/2025</td>
                                <td>Bara Brith, Té Galés</td>
                                <td>$320</td>
                                <td><span class="status delivered">+32 pts</span></td>
                            </tr>

                            <tr>
                                <td>15/02/2025</td>
                                <td>Menú Degustación</td>
                                <td>$1500</td>
                                <td><span class="status delivered">+150 pts</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Próximas Promociones -->
                <div class="recentCustomers">
                    <div class="cardHeader">
                        <h2>Próximos Beneficios</h2>
                    </div>

                    <table>
                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="Imagenes/Descuento.jpg" alt=""></div>
                            </td>
                            <td>
                                <h4>15% Descuento <br> <span>500 pts necesarios</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="Imagenes/Postre.jpg" alt=""></div>
                            </td>
                            <td>
                                <h4>Postre Gratis <br> <span>300 pts necesarios</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="Imagenes/Vino.jpg" alt=""></div>
                            </td>
                            <td>
                                <h4>Botella de Vino <br> <span>700 pts necesarios</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="Imagenes/Cena.jpg" alt=""></div>
                            </td>
                            <td>
                                <h4>Cena para 2 <br> <span>1200 pts necesarios</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="Imagenes/Privado.jpg" alt=""></div>
                            </td>
                            <td>
                                <h4>Evento Privado <br> <span>2000 pts necesarios</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="Imagenes/Charles_miamor.jpg" alt=""></div>
                            </td>
                            <td>
                                <h4>Clase con Chef <br> <span>1500 pts necesarios</span></h4>
                            </td>
                        </tr>
                    </table>
                </div>
             </div>
        </div>
</div>

<script src="JS/main.js"></script>

<!-- iconos -->
 <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
 <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>